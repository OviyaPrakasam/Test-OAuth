package com.scb.bsoi.controller;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.scb.ssapi.service.TermsAndConditionsService;
import com.scb.ssapi.vo.TncRequestVO;
import com.scb.ssapi.vo.TncResponseVO;

@Component
@Path("/tnc")
public class TermsAndConditionsController {

    @Autowired
    private TermsAndConditionsService tncService;

    @GET
    @Path("/check")
    @Produces(MediaType.APPLICATION_JSON)
    public Response checkTnC(@QueryParam("customerId") String customerId) {
        try {
            TncResponseVO response = tncService.checkTnCStatus(customerId);
            return Response.ok(response).build();
        } catch (Exception e) {
            return Response.serverError().entity("Error checking T&C status").build();
        }
    }

    @POST
    @Path("/update")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response updateTnC(TncRequestVO request) {
        try {
            tncService.updateTnCAcceptance(request.getCustomerId(), request.getTermVersion());
            return Response.ok().build();
        } catch (Exception e) {
            return Response.serverError().entity("Error updating T&C status").build();
        }
    }

    @POST
    @Path("/init")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response initTnC(String jsonInput) {
        try {
            String termVersion = tncService.initializeTnC(jsonInput);
            return Response.ok("{\"termVersion\":\"" + termVersion + "\"}").build();
        } catch (Exception e) {
            return Response.serverError().entity("Error initializing T&C").build();
        }
    }
}
