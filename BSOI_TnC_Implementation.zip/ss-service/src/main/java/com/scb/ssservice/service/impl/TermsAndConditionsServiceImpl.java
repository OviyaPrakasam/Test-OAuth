package com.scb.ssservice.service.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.common.constants.CommonConstant;
import com.scb.ssapi.service.TermsAndConditionsService;
import com.scb.ssapi.vo.TncResponseVO;
import com.scb.customer.dao.CustomerDAO;
import com.scb.customer.vo.CustomerVO;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class TermsAndConditionsServiceImpl implements TermsAndConditionsService {

    @Autowired
    private CustomerDAO customerDAO;

    @Override
    public TncResponseVO checkTnCStatus(String customerId) throws Exception {
        CustomerVO customerVO = customerDAO.findCustomerById(customerId);

        String termVersion = customerVO.getTcVersionNo();
        String isAccepted = customerVO.getIsTCAccepted();

        TncResponseVO response = new TncResponseVO();
        response.setTermVersion(termVersion);
        response.setTncRequired(
            CommonConstant.CONST_N.equalsIgnoreCase(isAccepted) || termVersion == null
        );
        return response;
    }

    @Override
    public void updateTnCAcceptance(String customerId, String termVersion) throws Exception {
        CustomerVO customerVO = customerDAO.findCustomerById(customerId);

        customerVO.setIsTCAccepted(CommonConstant.CONST_Y);
        customerVO.setTcAcceptedTime(new Date());
        customerVO.setTcVersionNo(termVersion);

        customerDAO.updateUserTnCInfo(customerVO);
    }

    @Override
    public String initializeTnC(String tncJson) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode rootNode = mapper.readTree(tncJson);
        JsonNode termsOuterArray = rootNode.path("terms");

        if (termsOuterArray.isArray() && !termsOuterArray.isEmpty()) {
            JsonNode termInnerArray = termsOuterArray.get(0);
            for (JsonNode term : termInnerArray) {
                String termVersion = term.path("term-version").asText();
                return termVersion;
            }
        }
        return CommonConstant.IBNK_TNC_DEFAULT_VERSION;
    }
}
