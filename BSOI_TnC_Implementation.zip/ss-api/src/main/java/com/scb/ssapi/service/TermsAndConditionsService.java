package com.scb.ssapi.service;

import com.scb.ssapi.vo.TncRequestVO;
import com.scb.ssapi.vo.TncResponseVO;

public interface TermsAndConditionsService {

    TncResponseVO checkTnCStatus(String customerId) throws Exception;

    void updateTnCAcceptance(String customerId, String termVersion) throws Exception;

    String initializeTnC(String tncJson) throws Exception;
}
