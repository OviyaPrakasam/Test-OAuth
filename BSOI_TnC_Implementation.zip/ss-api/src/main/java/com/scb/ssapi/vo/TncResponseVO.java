package com.scb.ssapi.vo;

public class TncResponseVO {
    private boolean tncRequired;
    private String termVersion;

    public boolean isTncRequired() {
        return tncRequired;
    }

    public void setTncRequired(boolean tncRequired) {
        this.tncRequired = tncRequired;
    }

    public String getTermVersion() {
        return termVersion;
    }

    public void setTermVersion(String termVersion) {
        this.termVersion = termVersion;
    }
}
