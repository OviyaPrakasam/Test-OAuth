package com.example.bsoi.delegate;

import com.example.ssapi.service.TnCService;
import javax.ws.rs.core.Response;

public class TnCDelegate {
    private TnCService tncService;

    public TnCDelegate(TnCService tncService) {
        this.tncService = tncService;
    }

    public Response checkTnC(String customerId) {
        return tncService.checkTnC(customerId);
    }

    public Response updateTnC(String customerId, String version) {
        return tncService.updateTnC(customerId, version);
    }

    public Response initTnC(String json) {
        return tncService.initTnC(json);
    }
}