package com.example.bsoi.endpoint.implementation;

import com.example.bsoi.delegate.TnCDelegate;
import com.example.bsoi.endpoint.request.TnCUpdateRequest;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/tnc")
public class TnCEndpoint {

    private TnCDelegate delegate = new TnCDelegate(new com.example.ssservice.service.impl.TnCServiceImpl());

    @GET
    @Path("/check")
    @Produces(MediaType.APPLICATION_JSON)
    public Response checkTnC(@QueryParam("customerId") String customerId) {
        return delegate.checkTnC(customerId);
    }

    @POST
    @Path("/update")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateTnC(TnCUpdateRequest request) {
        return delegate.updateTnC(request.getCustomerId(), request.getVersion());
    }

    @POST
    @Path("/init")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response initTnC(String json) {
        return delegate.initTnC(json);
    }
}