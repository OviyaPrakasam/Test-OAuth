package com.example.bsoi.endpoint.request;

public class TnCUpdateRequest {
    private String customerId;
    private String version;

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }
}