package com.example.bsoi.endpoint.response;

public class TnCCheckResponse {
    private boolean showTnC;

    public boolean isShowTnC() {
        return showTnC;
    }

    public void setShowTnC(boolean showTnC) {
        this.showTnC = showTnC;
    }
}