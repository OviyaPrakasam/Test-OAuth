package com.example.ssapi.service;

import javax.ws.rs.core.Response;

public interface TnCService {
    Response checkTnC(String customerId);
    Response updateTnC(String customerId, String version);
    Response initTnC(String tncJson);
}